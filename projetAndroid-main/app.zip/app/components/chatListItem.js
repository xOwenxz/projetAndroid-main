import React from 'react';
import { View, Button, Text, StyleSheet, Image, TextInput} from 'react-native';

export default () =>{
  return(
    <View>
    </View>
  );
}