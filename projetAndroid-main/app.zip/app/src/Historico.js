import {useState} from 'react';
import { View, Button, Text} from 'react-native';

const Historico = ()=>{return(<Text>Historico</Text>)}

export default Historico;