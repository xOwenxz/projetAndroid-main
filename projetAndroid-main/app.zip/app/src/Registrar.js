import {useState} from 'react';
import { View, Button, Text} from 'react-native';

const Registrar = ()=>{return(<Text>Registrar</Text>)}

export default Registrar;