import {useState} from 'react';
import { View, Button, Text} from 'react-native';

const Sobre = ()=>{return(<Text>Avisos</Text>)}

export default Sobre;