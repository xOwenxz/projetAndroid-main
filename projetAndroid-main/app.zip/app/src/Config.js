import {useState} from 'react';
import { View, Button, Text} from 'react-native';

const Config = ()=>{return(<Text>Config</Text>)}

export default Config;